# PubMed Research Papers Fetcher

## Overview

This Python project provides a robust tool to fetch research papers from PubMed using NCBI's E-utilities API. The application allows users to search for research papers, retrieve detailed information, and export the results to a CSV file.

## Background

[PubMed](https://pubmed.ncbi.nlm.nih.gov/) is a free resource maintained by the National Center for Biotechnology Information (NCBI), hosting millions of biomedical and life sciences research papers. The project leverages NCBI's E-utilities public API to efficiently search and retrieve research paper information.

## Key Features

- Search research papers using flexible query terms
- Retrieve comprehensive paper details
- Export results to CSV
- Debug mode for troubleshooting
- Lightweight and easy to use

## Prerequisites

- Python 3.8+


## Installation (If you are seeing this on TestPyPI)
1. Using virtual environment is preffered.

2. Copying the command at the page `https://test.pypi.org/project/fetch-pubmed-data/#description` will give error, as this module was created using poetry dependency management and needs some dependency to work with. However, TestPyPI does not host dependencies, therefore you should also allow pip to fetch them from the main PyPI, use the command below
```bash
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple fetch-pubmed-data
```

3. Create a new python file (ex-app.py) and add the below contents 
```bash
from fetch_pubmed_data import fetch_data
fetch_data()
```

## Usage Examples (with reference to app.py, if you've created different replace the name)

### Basic Search
```bash
# Search for papers about diabetes drug
python app.py "diabetes drug"
```

### Export to CSV
```bash
# Save results to info.csv
python app.py "diabetes drug" -f info.csv
```

### Debug Mode
```bash
# Enable verbose debugging
python app.py "diabetes drug" -d
```

## Program Workflow

### 1. Search API
- Retrieves list of Unique Identifiers (UIDs) matching the query
- Endpoint: `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi`
- Example Query: `term="diabetes drug", db="pubmed"`

### 2. Downloading API
- Fetches document summaries for input UIDs
- Endpoint: `https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi`

### 3. Data Extraction
- Parses XML response
- Extracts relevant information:
  - PubMed ID
  - Article Title
  - Publication Date
  - Authors
- Stores data in CSV format

## Dependencies

- `requests`: HTTP library for API calls
- `argparse`: Command-line argument parsing
- `xml.etree.ElementTree`: XML parsing

## Limitations and Considerations

- Respects NCBI's usage guidelines
- Rate-limited by NCBI
- Requires stable internet connection

## Acknowledgments

- [PubMed E-utilities Documentation](https://eutils.ncbi.nlm.nih.gov/)
- AI Tools (ChatGPT, Claude) for debugging assistance
- Poetry for dependency management


## Contact
- Name: Palash Shrote
- Email: palash.shrote.58@gmail.com