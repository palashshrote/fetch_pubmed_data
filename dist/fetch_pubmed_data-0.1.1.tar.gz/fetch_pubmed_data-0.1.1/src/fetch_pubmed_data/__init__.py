from .cli import fetch_data
